# iOS Bootcamp Week1

1. Please download sample project from given github repository.
2. Create your own repository and initiate master and develop branches. 
3. Create feature branches and commit source code by solving given algorithm. By this means you will able to create different branches and merge them onto develop. Final project must be merged on develop branch. 
4. Please solve algorithm questions by following instructions in the source code.
 
