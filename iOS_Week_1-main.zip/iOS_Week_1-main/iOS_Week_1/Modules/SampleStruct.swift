//
//  SampleStruct.swift
//  iOS_Week_1
//
//  Created by Erkut Bas on 19.09.2021.
//

import Foundation

struct SampleStruct {
    let title: String
    let subTitle: String
}
